# 问题二独立求解代码包

Python 3.12 已验证，求解仅依赖标准库。本包不含预先求出的方案、成绩表或用例答案。输入图由使用者提供。

运行：`python solution/q2_submit.py graph.json -n 5 --config config.txt -o graph_multicore_res.json`。

输出 JSON 只含 node_to_subgraph 与 core_schedules；旁边的 *_search 目录保存诊断。每次调用重新开始，最多 24 次原版评估，180 秒为搜索软预算，并非硬进程时限。可用核数 2～5；1 核基准按题意单独计算。

独立复核：`python official/code/multicore_cut_evaluate_problem_2.py graph.json graph_multicore_res.json --config config.txt`。official/code 与 config.txt 均保留题给原版。
