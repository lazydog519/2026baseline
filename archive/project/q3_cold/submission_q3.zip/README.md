# 第三问独立冷启动提交代码

每次运行只读当前图、原始 config.txt 和固定算法参数；输出方案仅含 node_to_subgraph 与 core_schedules。原始图、评测器、缓存规则均未更改。

环境：Python 3.12；安装 requirements.txt。原版事件评测为 CPU 程序。

运行：`python solution/q3_fusion_submit.py 输入图.json -n 5 --config official/data/config.txt -o 输出方案.json`

n 可取 1～5。每例重新构造候选；条件触发的 U-NSGA-III 也从当前图独立初始化。
