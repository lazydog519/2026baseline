# 问题一独立求解代码包

Python 3.12 已验证，求解仅依赖标准库。输入图需另行提供。

`python solution/q1_submit.py graph.json -n 5 --config config.txt -o graph_multicore_res.json`

每次从当前图重新构造候选，至多六次官方评估；不读取历史答案、成绩或其他用例。2～5 核输出 JSON 仅含 node_to_subgraph 与 core_schedules；1 核基准按题意单独计算。诊断写入相邻的 *_search 目录，每次评估后落盘。计数上限不等于运行秒数上限。

独立复核：`python official/code/multicore_cut_evaluate_problem_1.py graph.json graph_multicore_res.json --config config.txt`。附录原评估器与固定配置未改动。
