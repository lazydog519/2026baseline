Python with numpy and pymoo==0.6.1.6 required.
Run q3_fusion/submit.py official/data/<graph>.json -n 5.
The graph and config.txt must be in the same directory.
The output plan contains only node_to_subgraph and core_schedules.
