# Q3 deterministic cold-start prototype

Small-pilot prototype, not a fully validated final competition submission.
No cases, results or historical plans are included. Python standard library only.
Unzip and run from the package root:

python q3_design/q3_pilot_solver.py /path/to/input.json -n 2 --config official/data/config.txt --output-dir new_run
python official/code/multicore_cut_evaluate_problem_3.py /path/to/input.json new_run/plan.json --config official/data/config.txt

plan.json has exactly node_to_subgraph and core_schedules. The evaluator accepts
the explicit plan path. For default lookup, copy it beside the input as
<input_stem>_multicore_res.json without modifying content.
Every invocation derives candidates only from the current input and fixed
configuration; candidate evaluations start with empty L2. Source helpers contain
construction routines, not precomputed solutions.
