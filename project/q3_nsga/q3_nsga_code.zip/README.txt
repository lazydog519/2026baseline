Exploratory Q3 prototype; not a completed full-data submission.
Install: python -m pip install -r q3_nsga/requirements.txt
Run: python q3_nsga/solve.py /path/to/input.json -n 5 --config official/data/config.txt --method unsga3_npu --seed 17 --output new_run
Plan new_run/plan.json contains exactly the two required fields.
Only code and fixed configuration included; no input cases or old solutions.
